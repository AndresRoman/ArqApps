package Persistencia;

import Dominio.Entidades.Administrador;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7abe2a12-b57c-4b9e-83ef-c745dcdb9d02")
public class RepositorioAdministrador {
    @objid ("21400a14-a3ce-4b24-ab87-f033b5cf1f07")
    public Administrador administrador;

    @objid ("76716e32-8fb7-46c4-b42e-f524a4c1c498")
    public void Ingresar() {
    }

    @objid ("dd8a8b28-34d6-4852-b3b5-a822a3b109e4")
    public void Get() {
    }

}
