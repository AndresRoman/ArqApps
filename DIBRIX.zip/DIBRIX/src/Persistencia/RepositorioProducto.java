package Persistencia;

import Dominio.Entidades.Producto;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ec15e889-acb4-4951-a6d8-d4c92ad3840d")
public class RepositorioProducto {
    @objid ("76be8f55-16da-4dd3-a424-b340a6d8750b")
    public Producto producto;

    @objid ("0bd0cb35-d3f7-452f-b10d-fdf54b4640f5")
    public void Ingresar() {
    }

    @objid ("ac4a67a6-f6bb-477f-a33a-ca184c488da2")
    public void Get() {
    }

    @objid ("c0795d6f-3f0a-4745-97c9-11301bccf47f")
    public void VerificarExistencia() {
    }

}
