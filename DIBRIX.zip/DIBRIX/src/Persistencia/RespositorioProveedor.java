package Persistencia;

import Dominio.Entidades.Proveedor;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7edf042d-98b6-43e8-9579-d1f9b95845cf")
public class RespositorioProveedor {
    @objid ("92cb9021-01e4-4af4-9112-5f2b80515f72")
    public Proveedor proveedor;

    @objid ("9fc95cc2-9094-485e-882e-fc094308582c")
    public void Ingresar() {
    }

    @objid ("5319931e-ba28-4315-9a4f-3c4f5a8f518c")
    public void Get() {
    }

    @objid ("4e2103f4-67b5-4942-9bdd-7959491ff8ef")
    public void VerificarExistencia() {
    }

}
