package Persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f5203462-76c9-4eca-af6d-3558175542b6")
public interface OperacionesAdministrador {
    @objid ("0ba899de-c3e9-47fb-a9db-bcb44415ec0f")
    void Ingresar();

    @objid ("d0e45284-64c2-43c4-a475-aac7e325c458")
    void Get();

}
