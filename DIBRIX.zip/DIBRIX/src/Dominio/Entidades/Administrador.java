package Dominio.Entidades;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("dc930aac-e2ed-422a-984e-2a985efe0861")
public class Administrador {
    @objid ("77dfc792-1e70-4a00-a035-f5981e9abeee")
    public String Codigo;

    @objid ("6a1feada-973f-487f-82da-a5f2f6cca338")
    public String Nombre;

    @objid ("07c8f542-db20-4018-9c89-b63a4da243c4")
    public String Telefono;

    @objid ("b7b8795c-c8ed-4017-b558-0bec9d281815")
    public String Correo;

}
