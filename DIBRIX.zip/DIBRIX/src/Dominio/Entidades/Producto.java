package Dominio.Entidades;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2b6d25b1-f5cb-4643-a0fd-aaf5bf0b751f")
public class Producto {
    @objid ("39196305-6543-4789-9bf4-50a612c462a0")
    public String Codigo;

    @objid ("68a19add-3f7e-47dd-8891-5399f8071aaf")
    public String Nombre;

    @objid ("f114f197-c2b7-46cc-9f9c-2b6670d049a6")
    public String Tipo;

    @objid ("d42c9b9c-2b2b-4e26-ba83-2a67dee50e41")
    public int Cantidad;

}
