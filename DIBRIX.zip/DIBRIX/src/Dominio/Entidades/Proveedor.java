package Dominio.Entidades;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("df89f0f3-14d9-407d-b067-9d3c25a0bd94")
public class Proveedor {
    @objid ("bf9734f7-658f-4be3-92cf-30f9c53971c7")
    public String Codigo;

    @objid ("68f91a94-4eb5-4f7b-aa59-b8022d3313e3")
    public String Nombre;

    @objid ("cac78ad6-7717-44a6-a94e-d381365d4a4b")
    public String Telefono;

    @objid ("6cf97e78-ddb0-46ce-a3e2-609a0a32b42f")
    public String Correo;

    @objid ("f5f74c8e-5d6b-406f-881f-11f6f5593ce4")
    public String Direccion;

}
