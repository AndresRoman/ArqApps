package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b4422f1b-a477-4c14-926a-5536eb342500")
public class MostrarMasEntreado {
    @objid ("b3537940-3a05-409d-864d-bd9f1c40042c")
    public void MostrarMasEntregado() {
    }

}
