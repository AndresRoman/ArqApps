package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1380e35e-bd0b-4dd8-990c-2fe14cad8fe2")
public class IngresarProductos {
    @objid ("e5381661-f35f-402e-b333-551b94d95ac7")
    public void IngresarProducto() {
    }

    @objid ("a43b2400-f72c-4c2d-b296-e95828a49347")
    public void VerificarExistenciaProducto() {
    }

}
