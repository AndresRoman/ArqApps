package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c84e43e8-8fe7-4a44-8888-20d74aa9cba3")
public class MostrarProductos {
    @objid ("643a3ab7-537c-4186-8985-5b574b2627b1")
    public void MostrarProductos() {
    }

}
