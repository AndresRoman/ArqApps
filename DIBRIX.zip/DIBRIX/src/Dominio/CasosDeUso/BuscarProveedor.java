package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f4615adc-4c8b-4350-a193-00071af93024")
public class BuscarProveedor {
    @objid ("48a8e2f2-b277-4fb9-88aa-d45ebe1e8115")
    public void BuscarProveedor() {
    }

}
