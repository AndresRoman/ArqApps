package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9f5fb80f-20bd-4c71-8598-1e6c673928c8")
public class BuscarProductos {
    @objid ("bd1de47c-13ab-4da1-a3df-e54c140c0842")
    public void BuscarProducto() {
    }

}
