package Dominio.CasosDeUso;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d345dac4-5fd9-4359-8a00-6ea900a52489")
public class IngresarProveedor {
    @objid ("0d2d08be-dff5-49a7-a81b-4a2204120d7f")
    public void VerificarExistenciaProveedor() {
    }

    @objid ("1764c2cf-2f3b-47c5-86cb-65e12d7cca66")
    public void IngresarProveedor() {
    }

}
